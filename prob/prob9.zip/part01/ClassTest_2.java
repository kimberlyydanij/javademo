package java009_inheritance.prob.part01;

public class ClassTest_2 {

}
