package java011_casting.part01;

public class Parent {
	
	public Parent() {
		// TODO Auto-generated constructor stub
	}
	
	void process() {
		System.out.println("Parent");
	}

}
