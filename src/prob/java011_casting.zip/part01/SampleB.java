package java011_casting.part01;

public class SampleB {

}
