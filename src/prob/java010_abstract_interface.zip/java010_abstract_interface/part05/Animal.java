package java010_abstract_interface.part05;

public class Animal {
	public Animal() {

	}
	
	void play() {
		System.out.println("animal");
	}
}
