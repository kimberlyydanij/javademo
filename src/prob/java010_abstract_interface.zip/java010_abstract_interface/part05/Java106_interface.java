package java010_abstract_interface.part05;

public class Java106_interface {

	public static void main(String[] args) {
		Life life = new Life();
		life.prn();
		life.play();
	}//end main()

}//end class
