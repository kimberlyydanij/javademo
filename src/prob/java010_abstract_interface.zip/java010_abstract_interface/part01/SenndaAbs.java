package java010_abstract_interface.part01;

public class SenndaAbs extends CarAbs {

	public SenndaAbs() {

	}

	@Override
	public void work() {	
          System.out.println("승용차가 사람을 태우고 있습니다.");
	}

}
