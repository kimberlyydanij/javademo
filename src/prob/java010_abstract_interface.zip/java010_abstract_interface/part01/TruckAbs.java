package java010_abstract_interface.part01;

public class TruckAbs extends CarAbs{
	public TruckAbs() {
	
	}
	
	@Override
	public void work() {
	   System.out.println("트럭에 짐을 싣고 있다.");		
	}

}
