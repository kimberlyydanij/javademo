package java010_abstract_interface.part06;

public interface Score {
	public int sol = 20;

	public int getScore();

}
