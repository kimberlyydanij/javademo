package java010_abstract_interface.part07;

public class UserFinal  extends FinalTest{
  public UserFinal() {

  }
  
  //Cannot override the final method from FinalTest
  //void process() {  }
  
}
