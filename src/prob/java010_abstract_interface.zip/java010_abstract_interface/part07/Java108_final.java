package java010_abstract_interface.part07;


/*
 * final
 * class : 상속을 할 수 없는 클래스
 * method : 오버라이딩을 할 수 없는 메소드
 * variable : 상수
 */
public class Java108_final {

	public static void main(String[] args) {
		
	}

}
