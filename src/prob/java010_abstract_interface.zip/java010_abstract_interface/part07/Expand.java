package java010_abstract_interface.part07;

//The type Expand cannot subclass the final class Base
public class Expand /*extends Base*/ {

}
