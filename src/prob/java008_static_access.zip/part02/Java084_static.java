package java008_static_access.part02;

public class Java084_static {

	public static void main(String[] args) {
		OrderStatic os = new OrderStatic();
		os.display();
	}

}
