package java003_statements;

/*
 * for(초기식; 조건식; 증감식){
 *   반복 수행할 문장;
 * }
 */
public class Java024_for {

	public static void main(String[] args) {
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		System.out.println(4);
		System.out.println(5);
		
		for(int i =1; i<=5; i++) {
			System.out.println(i);
		}

	}

}
